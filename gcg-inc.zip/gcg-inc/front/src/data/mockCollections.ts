    export const mockCollections = [
      { id: 'summer', title: 'Summer Campaign', products: ['1', '3'] },
      { id: 'heritage', title: 'Heritage', products: ['2'] },
    ];


